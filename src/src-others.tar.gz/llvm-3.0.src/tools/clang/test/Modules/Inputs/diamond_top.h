int top(int *);

int top_left(char *c);

