// This is the first thing other than comments and preprocessor stuff in the
// file.
//
// RUN: %clang_cc1 -fms-extensions -E %s
#pragma comment(lib, "somelib")
