// RUN: %clang -fsyntax-only %s -print-stats
#ifdef __APPLE__
#include <Carbon/Carbon.h>
#endif

