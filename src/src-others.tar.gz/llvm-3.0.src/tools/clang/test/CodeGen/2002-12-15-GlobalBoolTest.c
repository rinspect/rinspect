// RUN: %clang_cc1 -emit-llvm %s  -o /dev/null


_Bool X = 0;

