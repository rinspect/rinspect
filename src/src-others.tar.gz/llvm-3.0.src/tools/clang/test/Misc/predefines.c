/* RUN: %clang_cc1 -fsyntax-only -verify -std=c89 -ffreestanding -pedantic-errors %s
 * rdar://6814950
 */
#include <stdint.h>

