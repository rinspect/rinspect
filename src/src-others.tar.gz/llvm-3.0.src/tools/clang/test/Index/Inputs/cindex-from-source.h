typedef int t0;
