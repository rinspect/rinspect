#ifndef MY_DEBUG_H
#define MY_DEBUG_H

#include <iostream>
#include <cstdlib>  //for abort

using std::cout;
using std::endl;
using std::cin;

void mypause();

#endif
