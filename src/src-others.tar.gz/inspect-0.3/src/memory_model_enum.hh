// this file is included by both server and client, so that they have the same convention on mode
#ifndef MEMORY_MODEL_ENUM_H
#define MEMORY_MODEL_ENUM_H
enum MemoryModel {SC_MODEL, TSO_MODEL, PSO_MODEL};
#endif
